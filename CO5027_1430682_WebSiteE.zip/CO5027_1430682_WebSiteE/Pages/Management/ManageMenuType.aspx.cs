﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_Management_ManageMenuType : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnsubmit_click(object sender, EventArgs e)
    {

        MenuTypeModel model = new MenuTypeModel();
        MenuType pt = CreateMenuType();

        Lblresult.Text = model.InsertMenuType(pt);
    }

    private MenuType CreateMenuType()
    {
        MenuType p = new MenuType();
        p.Name = txtname.Text;

        return p;
    }
}
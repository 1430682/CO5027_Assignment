﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Pages_Management_ManageProducts : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            GetImages();

            //Check if the url contains an id parameter
            if (!String.IsNullOrWhiteSpace(Request.QueryString["id"]))
            {
                int id = Convert.ToInt32(Request.QueryString["id"]);
                FillPage(id);
            }
        }
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        MenuModel menuModel = new MenuModel();
        Menu menu = CreateMenu();

      
        if (!String.IsNullOrWhiteSpace(Request.QueryString["id"]))
        {
            //ID exists -> Update existing row
            int id = Convert.ToInt32(Request.QueryString["id"]);
            lblResult.Text = menuModel.UpdateMenu(id, menu);
        }
        else
        {
            //ID does not exist -> Create a new row
            lblResult.Text = menuModel.InsertMenu(menu);
        }
    }

    private void FillPage(int id)
    {
        //Get selected menu from DB
        MenuModel menuModel = new MenuModel();
        Menu menu = menuModel.GetMenu(id);

        //Fill Textboxes
        txtdescription.Text = menu.Description;
        txtname.Text = menu.MenuName;
        txtprice.Text = menu.Price.ToString();

        //Set dropdownlist values
        ddimage.SelectedValue = menu.Image;
        ddtype.SelectedValue = menu.TypeId.ToString();
    }

    private void GetImages()
    {
        try
        {
            //Get all filepaths
            string[] images = Directory.GetFiles(Server.MapPath("~/Images/Menus/"));

            //Get all filenames and add them to an arraylist
            System.Collections.ArrayList imageList = new ArrayList();
            foreach (string image in images)
            {
                string imageName = image.Substring(image.LastIndexOf(@"\", StringComparison.Ordinal) + 1);
                imageList.Add(imageName);
            }

            //Set the arrayList as the dropdownview's datasource and refresh
            ddimage.DataSource = imageList;
            ddimage.AppendDataBoundItems = true;
            ddimage.DataBind();
        }
        catch (Exception e)
        {
            lblResult.Text = e.ToString();
        }
    }

    private Menu CreateMenu()
    {
        Menu menu = new Menu();

        menu.MenuName = txtname.Text;
        menu.Price = Convert.ToDecimal(txtprice.Text);
        menu.TypeId = Convert.ToInt32(ddtype.SelectedValue);
        menu.Description = txtdescription.Text;
        menu.Image = ddimage.SelectedValue;
         
        return menu;
    }




    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        MenuModel menumodel = new MenuModel();
        Menu menu = CreateMenu();

        lblResult.Text = menumodel.InsertMenu(menu);
    }
}
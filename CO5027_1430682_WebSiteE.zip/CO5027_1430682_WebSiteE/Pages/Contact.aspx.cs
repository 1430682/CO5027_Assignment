﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net.Mail;

public partial class Pages_Contact : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnsend_Click(object sender, EventArgs e)
    {

    }

    protected void send_message()
    {
        try
        {
            SmtpClient sendmail = new SmtpClient();
            sendmail.Host = "smtp.gmail.com";
            sendmail.Port = 587;
            sendmail.EnableSsl = true;

            System.Net.NetworkCredential userpass = new System.Net.NetworkCredential();
            userpass.UserName = "onlineroyalcatering@gmail.com";
            userpass.Password = "cateringservices";

            sendmail.Credentials = userpass;

            MailMessage msg = new MailMessage(txtemail.Text, "onlineroyalcatering@gmail.com");

            msg.Subject = "Comments from" + txtname.Text;
            msg.Body = txtmessage.Text;

            sendmail.Send(msg);
            Response.Write("<script>alert('Message has been sent')</script>");
            txtemail.Text = "";
            txtname.Text = "";
            txtmessage.Text = "";

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    protected void btnsend_click1(object sender, EventArgs e)
    {
        send_message();
    }

    
    protected void btnreset_click(object sender, EventArgs e)
    {
        txtname.Text = "";
        txtemail.Text = "";
        txtsubject.Text = "";
        txtmessage.Text = "";
    }
}
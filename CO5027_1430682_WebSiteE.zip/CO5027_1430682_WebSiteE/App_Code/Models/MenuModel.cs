﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for MenuModel
/// </summary>
public class MenuModel
{
    public static object menus;

    public static string Image { get; set; }
    public static object TypeId { get; set; }
    public static string MenuName { get; set; }
    public static string Price { get; set; }

   

    public string InsertMenu(Menu menu)
    {
        try
        {
            db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities();
            db.Menus.Add(menu);
            db.SaveChanges();

            return menu.MenuName + " was succesfully inserted";
        }
        catch (Exception e)
        {
            return "Error:" + e;
        }
    }

  

    public string UpdateMenu(int id, Menu menu)
    {
        try
        {
            db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities();

            //Fetch object from db
            Menu m = db.Menus.Find(id);

            m.MenuName = menu.MenuName;
            m.Price = menu.Price;
            m.TypeId = menu.TypeId;
            m.Description = menu.Description;
            m.Image = menu.Image;

            db.SaveChanges();
            return menu.MenuName + " was succesfully updated";

        }
        catch (Exception e)
        {
            return "Error:" + e;
        }
    }

    public string DeleteMenu(int id)
    {
        try
        {
            db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities();
            Menu menu = db.Menus.Find(id);

            db.Menus.Attach(menu);
            db.Menus.Remove(menu);
            db.SaveChanges();

            return menu.MenuName + " was succesfully deleted";
        }
        catch (Exception e)
        {
            return "Error:" + e;
        }
    }

    public Menu GetMenu(int id)
    {
        try
        {
            using (db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities())
            {
                Menu menu = db.Menus.Find(id);
                return menu;
            }
        }
        catch (Exception)
        {
            return null;
        }
    }

    public List<Menu> GetAllmenu()
    {
        try
        {
            using (db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities())
            {
                List<Menu> menus = (from x in db.Menus
                                          select x).ToList();
                return menus;
            }
        }
        catch (Exception)
        {

            return null;
        }
    }

    public List<Menu> GetMenusByType(int typeId)
    {
        try
        {
            using (db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities())
            {
                List<Menu> menus = (from x in db.Menus
                                          where x.TypeId == typeId
                                          select x).ToList();
                return menus;
            }
        }
        catch (Exception)
        {

            return null;
        }
    }

}
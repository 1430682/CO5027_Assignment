﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for MenuTypeModel
/// </summary>
public class MenuTypeModel
{
    public string InsertMenuType(MenuType menuType)
    {
        try
        {
            db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities();
            db.MenuTypes.Add(menuType);
            db.SaveChanges();

            return menuType.Name + " was succesfully inserted";
        }
        catch (Exception e)
        {
            return "Error:" + e;
        }
    }

    public string UpdateMenuType(int id, MenuType menuType)
    {
        try
        {
            db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities();

            //Fetch object from db
            MenuType p = db.MenuTypes.Find(id);

            p.Name = menuType.Name;

            db.SaveChanges();
            return menuType.Name + " was succesfully updated";

        }
        catch (Exception e)
        {
            return "Error:" + e;
        }
    }

    public string DeleteMenuType(int id)
    {
        try
        {
            db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities();
            MenuType menuType = db.MenuTypes.Find(id);

            db.MenuTypes.Attach(menuType);
            db.MenuTypes.Remove(menuType);
            db.SaveChanges();

            return menuType.Name + " was succesfully deleted";
        }
        catch (Exception e)
        {
            return "Error:" + e;
        }
    }

}
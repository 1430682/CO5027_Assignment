﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for MenuCartModel
/// </summary>
public class MenuCartModel
{
    public string InsertMenuCart(MenuCart menucart)
    {
        try
        {
           db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities();
            db.MenuCarts.Add(menucart);
            db.SaveChanges();

            return menucart.DatePurchased + " was succesfully inserted";
        }
        catch (Exception e)
        {
            return "Error:" + e;
        }
    }

    public string UpdateMenuCart(int id, MenuCart menucart)
    {
        try
        {
            db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities();

            //Fetch object from db
            MenuCart p = db.MenuCarts.Find(id);

            p.DatePurchased = menucart.DatePurchased;
            p.UserID = menucart.UserID;
            p.Amount = menucart.Amount;
            p.IsInCart = menucart.IsInCart;
            p.MenuID = menucart.MenuID;

            db.SaveChanges();
            return menucart.DatePurchased + " was succesfully updated";

        }
        catch (Exception e)
        {
            return "Error:" + e;
        }
    }

    public string DeleteMenuCart(int id)
    {
        try
        {
            db_1430682_CO5027_AssignmentEntities db = new db_1430682_CO5027_AssignmentEntities();
            MenuCart menucart = db.MenuCarts.Find(id);

            db.MenuCarts.Attach(menucart);
            db.MenuCarts.Remove(menucart);
            db.SaveChanges();

            return menucart.DatePurchased + "was succesfully deleted";
        }
        catch (Exception e)
        {
            return "Error:" + e;
        }
    }

}
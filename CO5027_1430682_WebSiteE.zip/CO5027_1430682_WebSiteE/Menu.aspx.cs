﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Menu : System.Web.UI.Page
{


    protected void Page_Load(object sender, EventArgs e)
    {
       
        {
            MenuModel model = new MenuModel();
            List<MenuModel> menus = model.GetAllmenus();

            if (menus != null)
            {
                foreach (MenuModel product in menus)
                {
                    Panel menuPanel = new Panel();
                    ImageButton imageButton = new ImageButton
                    {
                        ImageUrl = "~/Images/Menus/" + MenuModel.Image,
                        CssClass = "productImage",
                        PostBackUrl = string.Format("~/Pages/Menu.aspx?id={0}", MenuModel.TypeId)
                    };
                    Label lblName = new Label
                    {
                        Text = MenuModel.MenuName,
                        CssClass = "menuName"
                    };
                    Label lblPrice = new Label
                    {
                        Text = "£ " + MenuModel.Price,
                        CssClass = "menuPrice"
                    };

                    menuPanel.Controls.Add(imageButton);
                    menuPanel.Controls.Add(new Literal { Text = "<br/>" });
                    menuPanel.Controls.Add(lblName);
                    menuPanel.Controls.Add(new Literal { Text = "<br/>" });
                    menuPanel.Controls.Add(lblPrice);

                    //Add dynamic controls to static control
                    pnlMenu.Controls.Add(menuPanel);
                }
            }
            else
                pnlMenu.Controls.Add(new Literal { Text = "No menus found!" });
        }

    }
}